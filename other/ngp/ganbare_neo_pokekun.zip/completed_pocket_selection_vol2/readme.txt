NGPC Selection Vol. 2 instructions
----------------------------------
delete snapshot_gnpk.bin and copy savedata_gnpk.bin in NGPC Selection Vol. 2 savedata folder