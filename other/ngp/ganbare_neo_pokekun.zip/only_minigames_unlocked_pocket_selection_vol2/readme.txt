this savegame includes all minigames (but one) unlocked legitly, so you skip the grindy task
and can play all minigames!

last minigame should be easy to unlock: just make Poke-kun work twice and it will be unlocked
savegame has him very happy, so just enter and leave the minigame list a few times until he
goes to work


NGPC Selection Vol. 2 instructions
----------------------------------
delete snapshot_gnpk.bin and copy savedata_gnpk.bin in NGPC Selection Vol. 2 savedata folder